<?php
declare(strict_types=1);

namespace BuyRite\Salesform\Api\Data;

interface SalesformSearchResultsInterface extends \Magento\Framework\Api\SearchResultsInterface
{

    /**
     * Get Salesform list.
     * @return \BuyRite\Salesform\Api\Data\SalesformInterface[]
     */
    public function getItems();

    /**
     * Set id list.
     * @param \BuyRite\Salesform\Api\Data\SalesformInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}

