<?php
declare(strict_types=1);

namespace BuyRite\Salesform\Model;

use BuyRite\Salesform\Api\Data\SalesformInterface;
use BuyRite\Salesform\Api\Data\SalesformInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;

class Salesform extends \Magento\Framework\Model\AbstractModel
{

    protected $_eventPrefix = 'buyrite_salesform';
    protected $dataObjectHelper;

    protected $salesformDataFactory;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param SalesformInterfaceFactory $salesformDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \BuyRite\Salesform\Model\ResourceModel\Salesform $resource
     * @param \BuyRite\Salesform\Model\ResourceModel\Salesform\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        SalesformInterfaceFactory $salesformDataFactory,
        DataObjectHelper $dataObjectHelper,
        \BuyRite\Salesform\Model\ResourceModel\Salesform $resource,
        \BuyRite\Salesform\Model\ResourceModel\Salesform\Collection $resourceCollection,
        array $data = []
    ) {
        $this->salesformDataFactory = $salesformDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve salesform model with salesform data
     * @return SalesformInterface
     */
    public function getDataModel()
    {
        $salesformData = $this->getData();
        
        $salesformDataObject = $this->salesformDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $salesformDataObject,
            $salesformData,
            SalesformInterface::class
        );
        
        return $salesformDataObject;
    }
}

