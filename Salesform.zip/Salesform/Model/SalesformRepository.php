<?php
declare(strict_types=1);

namespace BuyRite\Salesform\Model;

use BuyRite\Salesform\Api\SalesformRepositoryInterface;
use BuyRite\Salesform\Api\Data\SalesformInterfaceFactory;
use BuyRite\Salesform\Api\Data\SalesformSearchResultsInterfaceFactory;
use BuyRite\Salesform\Model\ResourceModel\Salesform as ResourceSalesform;
use BuyRite\Salesform\Model\ResourceModel\Salesform\CollectionFactory as SalesformCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\ExtensibleDataObjectConverter;
use Magento\Framework\Api\ExtensionAttribute\JoinProcessorInterface;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Store\Model\StoreManagerInterface;

class SalesformRepository implements SalesformRepositoryInterface
{

    private $collectionProcessor;

    protected $dataObjectHelper;

    protected $extensionAttributesJoinProcessor;

    protected $salesformCollectionFactory;

    protected $salesformFactory;

    protected $searchResultsFactory;

    protected $dataObjectProcessor;

    protected $extensibleDataObjectConverter;
    protected $resource;

    protected $dataSalesformFactory;

    private $storeManager;


    /**
     * @param ResourceSalesform $resource
     * @param SalesformFactory $salesformFactory
     * @param SalesformInterfaceFactory $dataSalesformFactory
     * @param SalesformCollectionFactory $salesformCollectionFactory
     * @param SalesformSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     * @param CollectionProcessorInterface $collectionProcessor
     * @param JoinProcessorInterface $extensionAttributesJoinProcessor
     * @param ExtensibleDataObjectConverter $extensibleDataObjectConverter
     */
    public function __construct(
        ResourceSalesform $resource,
        SalesformFactory $salesformFactory,
        SalesformInterfaceFactory $dataSalesformFactory,
        SalesformCollectionFactory $salesformCollectionFactory,
        SalesformSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager,
        CollectionProcessorInterface $collectionProcessor,
        JoinProcessorInterface $extensionAttributesJoinProcessor,
        ExtensibleDataObjectConverter $extensibleDataObjectConverter
    ) {
        $this->resource = $resource;
        $this->salesformFactory = $salesformFactory;
        $this->salesformCollectionFactory = $salesformCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataSalesformFactory = $dataSalesformFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
        $this->collectionProcessor = $collectionProcessor;
        $this->extensionAttributesJoinProcessor = $extensionAttributesJoinProcessor;
        $this->extensibleDataObjectConverter = $extensibleDataObjectConverter;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \BuyRite\Salesform\Api\Data\SalesformInterface $salesform
    ) {
        /* if (empty($salesform->getStoreId())) {
            $storeId = $this->storeManager->getStore()->getId();
            $salesform->setStoreId($storeId);
        } */
        
        $salesformData = $this->extensibleDataObjectConverter->toNestedArray(
            $salesform,
            [],
            \BuyRite\Salesform\Api\Data\SalesformInterface::class
        );
        
        $salesformModel = $this->salesformFactory->create()->setData($salesformData);
        
        try {
            $this->resource->save($salesformModel);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the salesform: %1',
                $exception->getMessage()
            ));
        }
        return $salesformModel->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function get($salesformId)
    {
        $salesform = $this->salesformFactory->create();
        $this->resource->load($salesform, $salesformId);
        if (!$salesform->getId()) {
            throw new NoSuchEntityException(__('Salesform with id "%1" does not exist.', $salesformId));
        }
        return $salesform->getDataModel();
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->salesformCollectionFactory->create();
        
        $this->extensionAttributesJoinProcessor->process(
            $collection,
            \BuyRite\Salesform\Api\Data\SalesformInterface::class
        );
        
        $this->collectionProcessor->process($criteria, $collection);
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        
        $items = [];
        foreach ($collection as $model) {
            $items[] = $model->getDataModel();
        }
        
        $searchResults->setItems($items);
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \BuyRite\Salesform\Api\Data\SalesformInterface $salesform
    ) {
        try {
            $salesformModel = $this->salesformFactory->create();
            $this->resource->load($salesformModel, $salesform->getSalesformId());
            $this->resource->delete($salesformModel);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the Salesform: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($salesformId)
    {
        return $this->delete($this->get($salesformId));
    }
}

