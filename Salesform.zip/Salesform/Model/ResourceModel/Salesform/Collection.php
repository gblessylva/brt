<?php
declare(strict_types=1);

namespace BuyRite\Salesform\Model\ResourceModel\Salesform;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * @var string
     */
    protected $_idFieldName = 'id';
	protected $_previewFlag;
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init(
            \BuyRite\Salesform\Model\Salesform::class,
            \BuyRite\Salesform\Model\ResourceModel\Salesform::class
        );
		$this->_map['fields']['id'] = 'main_table.id';
    }
}

