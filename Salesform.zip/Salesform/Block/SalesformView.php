<?php

namespace BuyRite\Salesform\Block;

use Magento\Framework\View\Element\Template\Context;
use BuyRite\Salesform\Model\SalesformFactory;
use Magento\Cms\Model\Template\FilterProvider;
/**
 * Salesform View block
 */
class SalesformView extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Salesform
     */
    protected $_salesform;
    public function __construct(
        Context $context,
        SalesformFactory $salesform,
        FilterProvider $filterProvider
    ) {
        $this->_salesform = $salesform;
        $this->_filterProvider = $filterProvider;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('BuyRite Salesform Module View Page'));
        
        return parent::_prepareLayout();
    }

    public function getSingleData()
    {
        $id = $this->getRequest()->getParam('id');
        $salesform = $this->_salesform->create();
        $singleData = $salesform->load($id);
        if($singleData->getId() || $singleData['id'] && $singleData->getStatus() == 1){
            return $singleData;
        }else{
            return false;
        }
    }
}