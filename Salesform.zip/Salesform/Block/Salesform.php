<?php

namespace BuyRite\Salesform\Block;

/**
 * Salesform content block
 */
class Salesform extends \Magento\Framework\View\Element\Template
{
    /**
     * Index constructor.
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Directory\Model\Country $country,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->country = $country;
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('REQUEST A CATALOG'));
        
        return parent::_prepareLayout();
    }
    public function getRegionsOfCountry($countryCode) {
        $regionCollection = $this->country->loadByCode($countryCode)->getRegions();
        $regions = $regionCollection->loadData()->toOptionArray(false);
        return $regions;
    }
}
