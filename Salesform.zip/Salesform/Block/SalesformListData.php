<?php

namespace BuyRite\Salesform\Block;

use Magento\Framework\View\Element\Template\Context;
use BuyRite\Salesform\Model\SalesformFactory;
/**
 * Salesform List block
 */
class SalesformListData extends \Magento\Framework\View\Element\Template
{
    /**
     * @var Salesform
     */
    protected $_salesform;
    public function __construct(
        Context $context,
        SalesformFactory $salesform
    ) {
        $this->_salesform = $salesform;
        parent::__construct($context);
    }

    public function _prepareLayout()
    {
        $this->pageConfig->getTitle()->set(__('BuyRite Salesform Module List Page'));
        
        if ($this->getSalesformCollection()) {
            $pager = $this->getLayout()->createBlock(
                'Magento\Theme\Block\Html\Pager',
                'buyrite.salesform.pager'
            )->setAvailableLimit(array(5=>5,10=>10,15=>15))->setShowPerPage(true)->setCollection(
                $this->getSalesformCollection()
            );
            $this->setChild('pager', $pager);
            $this->getSalesformCollection()->load();
        }
        return parent::_prepareLayout();
    }

    public function getSalesformCollection()
    {
        $page = ($this->getRequest()->getParam('p'))? $this->getRequest()->getParam('p') : 1;
        $pageSize = ($this->getRequest()->getParam('limit'))? $this->getRequest()->getParam('limit') : 5;

        $salesform = $this->_salesform->create();
        $collection = $salesform->getCollection();
        $collection->addFieldToFilter('status','1');
        //$salesform->setOrder('id','ASC');
        $collection->setPageSize($pageSize);
        $collection->setCurPage($page);

        return $collection;
    }

    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}