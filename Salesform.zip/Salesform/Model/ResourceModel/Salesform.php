<?php

namespace BuyRite\Salesform\Model\ResourceModel;

class Salesform extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('buyrite_salesform', 'id');   //here "buyrite_salesform" is table name and "id" is the primary key of custom table
    }
}

