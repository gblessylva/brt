<?php
declare(strict_types=1);

namespace BuyRite\Salesform\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface SalesformRepositoryInterface
{

    /**
     * Save Salesform
     * @param \BuyRite\Salesform\Api\Data\SalesformInterface $salesform
     * @return \BuyRite\Salesform\Api\Data\SalesformInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(
        \BuyRite\Salesform\Api\Data\SalesformInterface $salesform
    );

    /**
     * Retrieve Salesform
     * @param string $salesformId
     * @return \BuyRite\Salesform\Api\Data\SalesformInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function get($salesformId);

    /**
     * Retrieve Salesform matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \BuyRite\Salesform\Api\Data\SalesformSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete Salesform
     * @param \BuyRite\Salesform\Api\Data\SalesformInterface $salesform
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(
        \BuyRite\Salesform\Api\Data\SalesformInterface $salesform
    );

    /**
     * Delete Salesform by ID
     * @param string $salesformId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($salesformId);
}

