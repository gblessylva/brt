<?php
namespace BuyRite\Salesform\Helper;

use Magento\Framework\App\Helper\Context;
use Magento\Framework\Mail\Template\TransportBuilder;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\Translate\Inline\StateInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;


class Data extends AbstractHelper
{
    protected $transportBuilder;
    protected $storeManager;
    protected $inlineTranslation;
    protected $scopeConfig;
    protected $_subscriber;

    public function __construct(
        Context $context,
        TransportBuilder $transportBuilder,
        StoreManagerInterface $storeManager,
        StateInterface $state,
        ScopeConfigInterface $scopeConfig,
        \Magento\Newsletter\Model\Subscriber $subscriber
    )
    {
        $this->transportBuilder = $transportBuilder;
        $this->storeManager = $storeManager;
        $this->scopeConfig = $scopeConfig;
        $this->inlineTranslation = $state;
        $this->_subscriber = $subscriber;
        
        parent::__construct($context);
    }

    public function sendEmail($last_name, $customer_email)
    {
        // this is an example and you can change template id,fromEmail,toEmail,etc as per your need.
        $templateId = 'request-catalog'; // template id
        $fromEmail = 'sales@buyritebeuty.com';  // sender Email id
        $fromName = 'Buyrite Sales';             // sender Name
        $toEmail = $customer_email; // receiver email id

        try {
            // template variables pass here
            $templateVars = [
                'last_name' => $last_name,
                'email' => $customer_email
            ];

            $storeId = $this->storeManager->getStore()->getId();

            $from = ['email' => $fromEmail, 'name' => $fromName];
            $this->inlineTranslation->suspend();

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $templateOptions = [
                'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => $storeId
            ];
            $transport = $this->transportBuilder->setTemplateIdentifier($templateId, $storeScope)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($toEmail)
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            $this->_logger->info($e->getMessage());
        }
    }

  

    public function sendAdminMail($last_name)
    {
        // this is an example and you can change template id,fromEmail,toEmail,etc as per your need.
        $templateId = 'admin-request-cataloq'; // template id
        $fromEmail = 'aladmines@buyritebeuty.com';  // sender Email id
        $fromName = 'Admin Sales';             // sender Name
        $toEmail = 'kodofin@neboagency.com'; // receiver email id

        try {
            // template variables pass here
            $templateVars = [
                'last_name' => $last_name,
                'email' => 'Here is a test message'
            ];

            $storeId = $this->storeManager->getStore()->getId();

            $from = ['email' => $fromEmail, 'name' => $fromName];
            $this->inlineTranslation->suspend();

            $storeScope = \Magento\Store\Model\ScopeInterface::SCOPE_STORE;
            $templateOptions = [
                'area' => \Magento\Framework\App\Area::AREA_FRONTEND,
                'store' => $storeId
            ];
            $transport = $this->transportBuilder->setTemplateIdentifier($templateId, $storeScope)
                ->setTemplateOptions($templateOptions)
                ->setTemplateVars($templateVars)
                ->setFrom($from)
                ->addTo($toEmail)
                ->getTransport();
            $transport->sendMessage();
            $this->inlineTranslation->resume();
        } catch (\Exception $e) {
            //$this->_logger->info($e->getMessage());
        }
    }
    public function creatingSubscribe($email)
    {
        
        
        $subscriber = $this->_subscriber;
        $subscriber->subscribe($email);

        $subscriber->save();
    }
}

